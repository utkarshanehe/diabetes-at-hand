 import React from "react";
  import { StatusBar, View, StyleSheet, Platform, BackHandler, Alert, AppState, AppStateStatus, Text } from "react-native";
  /*
   render() {
      return (
         <View>
            <Text>Welcome to Tutorialspoint</Text>
         </View>
      );
   }
}*/

export const ProfilePanel = {
render() {
      return (
         <View>
            <Text>Welcome to Tutorialspoint</Text>
         </View>
      );
   }
}