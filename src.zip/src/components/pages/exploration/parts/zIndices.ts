export namespace ZIndices {
    export const Header = 100
    export const Footer = 80
    export const dataBusyOverlay = 88
    export const dataBusyLoadingBar = 90

    export const TooltipOverlay = 2000
    export const GlobalSpeechOverlay = 2000
}