import { createStackNavigator, HeaderBackButton, TransitionPresets } from '@react-navigation/stack';
const HomeScreen = ({ navigation }) => {
  return (
    <Button
      title="Go to Jane's profile"


    />
  );
};

export {HomeScreen};