
export function getUploadServerHostUrl(): string | undefined {
    return undefined
}