declare module 'comma-number' {
    function commaNumber(number: number, separator?: string, decimalChar?: string): string
    export default commaNumber
}