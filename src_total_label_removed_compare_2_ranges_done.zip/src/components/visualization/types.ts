export enum Padding{
    Top=0,
    Right=1,
    Bottom=2,
    Left=3
}