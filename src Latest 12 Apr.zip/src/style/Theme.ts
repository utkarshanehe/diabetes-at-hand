import { TouchableOpacity } from "react-native";

export const theme = {
    Button: {
        TouchableComponent: TouchableOpacity
    }
}